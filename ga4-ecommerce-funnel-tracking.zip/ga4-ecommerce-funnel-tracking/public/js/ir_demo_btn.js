jQuery(document).ready(function () {
    console.log("Instructor Role page loaded");
    if (typeof dataLayer === 'undefined') {
      window.dataLayer = [];
  }
    var data = {};
    var section = document.querySelector('#section-id');
    
  data["btn_location"] = item_list_data["currency"];
  gtag('event', 'list_shop_page_products', data);
  });